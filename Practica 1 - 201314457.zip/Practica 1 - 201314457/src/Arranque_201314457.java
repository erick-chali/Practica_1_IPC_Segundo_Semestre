import javax.swing.*;

/**
 * Created by erickchali on 8/3/14.
 */
public class Arranque_201314457 {


    public static void main(String args[]){
        Interfaz_201314457 v = new Interfaz_201314457();
        v.setSize(750,400);
        v.setLocationRelativeTo(null);
        v.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        v.setResizable(false);
        v.setVisible(true);
    }
}
